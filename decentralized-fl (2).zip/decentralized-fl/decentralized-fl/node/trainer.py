"""
Local regression trainer.
Loss : MSE (training) + MAE reported as a human-readable metric.
Runs entirely on CPU — fast enough for a Raspberry Pi.
"""
import time
import logging
from typing import Dict, Any, List

import torch
import torch.nn.functional as F

from config import NodeConfig
from model import FLModel

logger = logging.getLogger(__name__)


class LocalTrainer:
    def __init__(
        self,
        model: FLModel,
        train_loader,
        test_loader,
        config: NodeConfig,
    ):
        self.model       = model
        self.train_loader = train_loader
        self.test_loader  = test_loader
        self.config       = config
        self.device       = torch.device("cpu")
        self.model.to(self.device)

        self.optimizer = torch.optim.Adam(
            self.model.parameters(),
            lr=config.learning_rate,
            weight_decay=1e-4,
        )
        self.scheduler = torch.optim.lr_scheduler.StepLR(
            self.optimizer, step_size=15, gamma=0.5
        )

        self.round: int = 0
        self.metrics_history: List[Dict[str, Any]] = []

    # ── Training ────────────────────────────────────────────────────────────

    def train_one_round(self) -> Dict[str, Any]:
        self.model.train()
        self.round += 1
        t0 = time.time()

        total_mse = 0.0
        total_mae = 0.0
        total_samples = 0

        for _epoch in range(self.config.local_epochs):
            for X, y in self.train_loader:
                X, y = X.to(self.device), y.to(self.device)
                self.optimizer.zero_grad()
                pred = self.model(X)
                loss = F.mse_loss(pred, y)
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
                self.optimizer.step()

                total_mse     += loss.item() * len(X)
                total_mae     += F.l1_loss(pred, y).item() * len(X)
                total_samples += len(X)

        self.scheduler.step()

        avg_mse = total_mse / max(total_samples, 1)
        avg_mae = total_mae / max(total_samples, 1)
        elapsed = time.time() - t0

        metrics: Dict[str, Any] = {
            "round":        self.round,
            "loss":         round(avg_mse, 6),   # MSE (used as "loss" across the app)
            "mae":          round(avg_mae, 6),
            "rmse":         round(avg_mse ** 0.5, 6),
            "accuracy":     round(max(0.0, 1.0 - avg_mae), 4),  # proxy 0–1 for dashboard
            "samples":      total_samples,
            "train_time_s": round(elapsed, 2),
            "lr":           self.optimizer.param_groups[0]["lr"],
        }
        self.metrics_history.append(metrics)
        logger.info(
            "Round %d: MSE=%.5f  MAE=%.5f  RMSE=%.5f  time=%.2fs",
            self.round, avg_mse, avg_mae, avg_mse ** 0.5, elapsed,
        )
        return metrics

    # ── Evaluation ──────────────────────────────────────────────────────────

    def evaluate(self) -> Dict[str, float]:
        """Evaluate on the held-out test set."""
        self.model.eval()
        total_mse = 0.0
        total_mae = 0.0
        total     = 0

        with torch.no_grad():
            for X, y in self.test_loader:
                X, y = X.to(self.device), y.to(self.device)
                pred = self.model(X)
                total_mse += F.mse_loss(pred, y, reduction="sum").item()
                total_mae += F.l1_loss(pred, y,  reduction="sum").item()
                total     += len(X)

        mse = total_mse / max(total, 1)
        mae = total_mae / max(total, 1)

        return {
            "test_loss":     round(mse, 6),
            "test_mae":      round(mae, 6),
            "test_rmse":     round(mse ** 0.5, 6),
            # Map MAE to a 0-1 accuracy proxy so the dashboard chart works
            "test_accuracy": round(max(0.0, 1.0 - mae), 4),
        }
