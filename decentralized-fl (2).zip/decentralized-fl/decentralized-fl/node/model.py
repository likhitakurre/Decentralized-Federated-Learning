"""
Tiny regression MLP.
Input: 10 normalised features (sklearn Diabetes dataset, or real sensors).
Output: 1 scalar (disease progression score, or whatever your target is).

~3k parameters — trains in under 2 seconds on a Raspberry Pi CPU.
Weights serialise to / from plain Python dicts (JSON-safe).

To adapt to real sensors:
  - Change input_size to match your feature count
  - Keep everything else identical
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, Any


class FLModel(nn.Module):
    """
    3-layer regression MLP:  10 → 64 → 32 → 1
    ~3,000 parameters. Gossip payload ≈ 50 KB JSON.
    """

    def __init__(
        self,
        input_size: int = 10,
        hidden1: int = 64,
        hidden2: int = 32,
        output_size: int = 1,
    ):
        super().__init__()
        self.fc1 = nn.Linear(input_size, hidden1)
        self.fc2 = nn.Linear(hidden1, hidden2)
        self.fc3 = nn.Linear(hidden2, output_size)
        self.bn1 = nn.BatchNorm1d(hidden1)
        self.bn2 = nn.BatchNorm1d(hidden2)
        self.dropout = nn.Dropout(p=0.1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = F.relu(self.bn1(self.fc1(x)))
        x = self.dropout(x)
        x = F.relu(self.bn2(self.fc2(x)))
        x = self.fc3(x)           # raw scalar — no activation for regression
        return x.squeeze(-1)

    # ── Serialisation helpers ───────────────────────────────────────────────

    def get_weights(self) -> Dict[str, Any]:
        return {k: v.cpu().tolist() for k, v in self.state_dict().items()}

    def set_weights(self, weights: Dict[str, Any]) -> None:
        state = {k: torch.tensor(v) for k, v in weights.items()}
        self.load_state_dict(state, strict=True)

    def count_parameters(self) -> int:
        return sum(p.numel() for p in self.parameters() if p.requires_grad)
