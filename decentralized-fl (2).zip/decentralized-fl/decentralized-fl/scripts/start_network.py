#!/usr/bin/env python3
"""
start_network.py
================
Launches N federated-learning nodes on localhost using different ports.
Designed for development / CI — on real edge hardware each node is a
separate device running `python main.py` directly.

Usage:
  python scripts/start_network.py --nodes 5 --base-port 8000

Each node:
  - Gets a unique NODE_ID  (node_0 … node_N-1)
  - Listens on BASE_PORT + i
  - Has all other nodes as peers
  - Trains on its own non-IID MNIST partition
"""

import argparse
import os
import signal
import subprocess
import sys
import time
import textwrap
from pathlib import Path
from typing import List

# ─── Colour helpers ────────────────────────────────────────────────────────

RESET = "\033[0m"
BOLD  = "\033[1m"
CYAN  = "\033[36m"
GREEN = "\033[32m"
AMBER = "\033[33m"
RED   = "\033[31m"
DIM   = "\033[2m"


def c(text: str, colour: str) -> str:
    return f"{colour}{text}{RESET}"


# ─── Main ──────────────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Start a local decentralized FL network for development"
    )
    parser.add_argument("--nodes",      type=int, default=5,    help="Number of nodes")
    parser.add_argument("--base-port",  type=int, default=8000, help="First port")
    parser.add_argument("--epochs",     type=int, default=1,    help="Local epochs per round")
    parser.add_argument("--batch-size", type=int, default=32,   help="Mini-batch size")
    parser.add_argument("--lr",         type=float, default=0.01, help="Learning rate")
    parser.add_argument("--gossip-interval", type=int, default=15, help="Gossip interval (s)")
    parser.add_argument("--train-interval",  type=int, default=20, help="Train interval (s)")
    parser.add_argument("--fanout",     type=int, default=2,    help="Gossip fanout")
    parser.add_argument("--iid",        action="store_true",    help="Use IID data splits")
    parser.add_argument("--data-dir",   default="./data",       help="Path to MNIST data")
    args = parser.parse_args()

    N         = args.nodes
    base_port = args.base_port
    node_dir  = Path(__file__).parent.parent / "node"

    ports    = [base_port + i for i in range(N)]
    peer_urls = [f"http://localhost:{p}" for p in ports]

    print(f"\n{BOLD}{CYAN}╔══════════════════════════════════════════════╗{RESET}")
    print(f"{BOLD}{CYAN}║  Decentralized Federated Learning Network    ║{RESET}")
    print(f"{BOLD}{CYAN}╚══════════════════════════════════════════════╝{RESET}\n")
    print(f"  Nodes      : {c(str(N), CYAN)}")
    print(f"  Ports      : {c(str(ports), CYAN)}")
    print(f"  Non-IID    : {c(str(not args.iid), CYAN)}")
    print(f"  Data dir   : {c(args.data_dir, CYAN)}")
    print(f"  Dashboard  : {c('open dashboard/index.html in your browser', GREEN)}")
    print()

    processes: List[subprocess.Popen] = []

    def shutdown(sig=None, frame=None):
        print(f"\n{AMBER}Shutting down all nodes…{RESET}")
        for p in processes:
            p.terminate()
        for p in processes:
            try:
                p.wait(timeout=5)
            except subprocess.TimeoutExpired:
                p.kill()
        print(c("All nodes stopped.", GREEN))
        sys.exit(0)

    signal.signal(signal.SIGINT,  shutdown)
    signal.signal(signal.SIGTERM, shutdown)

    for i in range(N):
        peers = [u for j, u in enumerate(peer_urls) if j != i]
        env   = {
            **os.environ,
            "NODE_ID":          f"node_{i}",
            "HOST":             "0.0.0.0",
            "PORT":             str(ports[i]),
            "PEERS":            ",".join(peers),
            "DATA_PARTITION":   str(i),
            "LOCAL_EPOCHS":     str(args.epochs),
            "BATCH_SIZE":       str(args.batch_size),
            "LEARNING_RATE":    str(args.lr),
            "GOSSIP_INTERVAL":  str(args.gossip_interval),
            "TRAIN_INTERVAL":   str(args.train_interval),
            "GOSSIP_FANOUT":    str(args.fanout),
            "NON_IID":          "false" if args.iid else "true",
            "DATA_DIR":         args.data_dir,
        }

        log_file = open(f"/tmp/fl_node_{i}.log", "w")
        proc = subprocess.Popen(
            [sys.executable, "-u", "main.py"],
            cwd=node_dir,
            env=env,
            stdout=log_file,
            stderr=log_file,
        )
        processes.append(proc)
        print(f"  {c('✓', GREEN)} Started {c(f'node_{i}', CYAN)} on port {c(str(ports[i]), CYAN)}  "
              f"{DIM}(log: /tmp/fl_node_{i}.log){RESET}")
        time.sleep(0.5)   # stagger startup slightly

    print(f"\n{GREEN}Network is running.{RESET} "
          f"Press {BOLD}Ctrl-C{RESET} to stop all nodes.\n")
    print(f"  Dashboard: {c('file:///path/to/dashboard/index.html', CYAN)}")
    print(f"  Direct API (node_0): {c('http://localhost:8000/status', CYAN)}\n")

    # Tail all logs to stdout with node prefix
    print(c("─" * 54, DIM))
    while True:
        for i, proc in enumerate(processes):
            if proc.poll() is not None:
                print(c(f"[node_{i}] process exited with code {proc.returncode}", RED))
        time.sleep(2)


if __name__ == "__main__":
    main()
