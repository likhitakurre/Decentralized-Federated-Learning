#!/usr/bin/env python3
"""
evaluate.py
===========
Queries all running nodes, fetches their test metrics, and prints
a convergence report. Can also train a centralized baseline model
on the full MNIST dataset for comparison.

Usage:
  # Report on live nodes
  python scripts/evaluate.py

  # Train centralized baseline and compare
  python scripts/evaluate.py --baseline --rounds 20
"""

import argparse
import sys
import time
from pathlib import Path
from typing import Optional

import requests

# Add node directory to path for model/data imports
sys.path.insert(0, str(Path(__file__).parent.parent / "node"))

CYAN   = "\033[36m"
GREEN  = "\033[32m"
AMBER  = "\033[33m"
RED    = "\033[31m"
RESET  = "\033[0m"
BOLD   = "\033[1m"
DIM    = "\033[2m"


# ─── Node querying ─────────────────────────────────────────────────────────

def query_nodes(urls: list[str]) -> dict:
    results = {}
    for url in urls:
        try:
            r = requests.get(f"{url}/status", timeout=5)
            r.raise_for_status()
            results[url] = r.json()
        except Exception as e:
            results[url] = None
    return results


def print_node_report(url: str, data: Optional[dict], idx: int) -> None:
    if data is None:
        print(f"  {RED}✗  {url}{RESET}  —  OFFLINE")
        return

    acc  = data.get("eval_metrics", {}).get("test_accuracy", 0)
    loss = data.get("eval_metrics", {}).get("test_loss",     0)
    rnd  = data.get("rounds_trained", 0)
    gos  = data.get("gossip", {}).get("successful_exchanges", 0)
    up   = data.get("uptime_s", 0)

    bar_len = int(acc * 30)
    bar     = "█" * bar_len + "░" * (30 - bar_len)

    print(
        f"  {GREEN}✓{RESET}  {CYAN}{data['node_id']:<10}{RESET}"
        f"  acc={BOLD}{acc*100:5.1f}%{RESET}  [{bar}]"
        f"  loss={AMBER}{loss:.4f}{RESET}"
        f"  rounds={rnd:<3}  gossips={gos:<4}  uptime={up:.0f}s"
    )


# ─── Centralized baseline ──────────────────────────────────────────────────

def run_centralized_baseline(rounds: int) -> list[dict]:
    """Train a baseline model on the full MNIST dataset."""
    import torch
    import torch.nn.functional as F
    from torchvision import datasets, transforms
    from torch.utils.data import DataLoader
    from model import FLModel

    print(f"\n{BOLD}Training centralized baseline ({rounds} rounds)…{RESET}")
    transform = transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize((0.1307,), (0.3081,)),
    ])
    train_ds = datasets.MNIST("./data", train=True,  download=True, transform=transform)
    test_ds  = datasets.MNIST("./data", train=False, download=True, transform=transform)
    train_dl = DataLoader(train_ds, batch_size=64, shuffle=True)
    test_dl  = DataLoader(test_ds,  batch_size=512)

    model = FLModel()
    opt   = torch.optim.SGD(model.parameters(), lr=0.01, momentum=0.9)
    history = []

    for r in range(1, rounds + 1):
        model.train()
        for data, target in train_dl:
            opt.zero_grad()
            F.nll_loss(model(data), target).backward()
            opt.step()

        model.eval()
        loss, correct, total = 0, 0, 0
        with torch.no_grad():
            for data, target in test_dl:
                out = model(data)
                loss    += F.nll_loss(out, target, reduction="sum").item()
                correct += out.argmax(1).eq(target).sum().item()
                total   += len(target)
        rec = {"round": r, "test_loss": loss/total, "test_accuracy": correct/total}
        history.append(rec)
        print(f"  Round {r:3d}: acc={rec['test_accuracy']*100:.2f}%  loss={rec['test_loss']:.4f}")

    return history


# ─── Main ──────────────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate FL network convergence")
    parser.add_argument("--urls",     nargs="+",
                        default=[f"http://localhost:{8000+i}" for i in range(5)],
                        help="Node URLs")
    parser.add_argument("--baseline", action="store_true", help="Run centralized baseline")
    parser.add_argument("--rounds",   type=int, default=10, help="Baseline rounds")
    parser.add_argument("--watch",    action="store_true",  help="Poll every 10s continuously")
    parser.add_argument("--interval", type=int, default=10, help="Watch interval")
    args = parser.parse_args()

    def report():
        print(f"\n{BOLD}{CYAN}══ FL Network Report — {time.strftime('%H:%M:%S')} ══{RESET}")
        data = query_nodes(args.urls)
        online = [d for d in data.values() if d is not None]

        for i, (url, d) in enumerate(data.items()):
            print_node_report(url, d, i)

        if online:
            accs  = [d["eval_metrics"].get("test_accuracy", 0) for d in online if d.get("eval_metrics")]
            print(f"\n  {DIM}{'─'*60}{RESET}")
            if accs:
                print(f"  Avg test accuracy : {BOLD}{sum(accs)/len(accs)*100:.2f}%{RESET}")
                print(f"  Best test accuracy: {GREEN}{max(accs)*100:.2f}%{RESET}")
                print(f"  Std dev           : {(sum((a - sum(accs)/len(accs))**2 for a in accs)/len(accs))**0.5 * 100:.2f}%")
            total_rounds  = sum(d.get("rounds_trained", 0) for d in online)
            total_gossips = sum(d.get("gossip", {}).get("successful_exchanges", 0) for d in online)
            print(f"  Total train rounds: {total_rounds}")
            print(f"  Total gossip exch : {total_gossips}")

    if args.watch:
        try:
            while True:
                report()
                time.sleep(args.interval)
        except KeyboardInterrupt:
            print(f"\n{GREEN}Watch stopped.{RESET}")
        return

    report()

    if args.baseline:
        bl = run_centralized_baseline(args.rounds)
        if bl:
            last = bl[-1]
            print(f"\n{BOLD}Centralized baseline after {args.rounds} rounds:{RESET}")
            print(f"  Test accuracy: {GREEN}{last['test_accuracy']*100:.2f}%{RESET}")
            print(f"  Test loss    : {AMBER}{last['test_loss']:.4f}{RESET}")


if __name__ == "__main__":
    main()
