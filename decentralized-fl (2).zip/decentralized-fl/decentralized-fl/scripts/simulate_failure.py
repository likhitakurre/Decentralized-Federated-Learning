#!/usr/bin/env python3
"""
simulate_failure.py
===================
Randomly kills and restarts FL nodes to demonstrate the system's
fault-tolerance under gossip-based model exchange.

Usage:
  # Kill node_2 for 30 seconds then bring it back
  python scripts/simulate_failure.py --kill node_2 --duration 30

  # Run random churn: every 20s kill a random node for 30s
  python scripts/simulate_failure.py --churn --interval 20 --downtime 30
"""

import argparse
import random
import subprocess
import sys
import time
import os
import signal
from pathlib import Path

CYAN  = "\033[36m"
GREEN = "\033[32m"
AMBER = "\033[33m"
RED   = "\033[31m"
RESET = "\033[0m"
BOLD  = "\033[1m"


def node_pid(node_id: str) -> int | None:
    """Find the PID of a running node by its NODE_ID env var."""
    try:
        result = subprocess.run(
            ["pgrep", "-f", f"NODE_ID={node_id}"],
            capture_output=True, text=True
        )
        pids = [int(p) for p in result.stdout.strip().split() if p]
        return pids[0] if pids else None
    except Exception:
        return None


def kill_node(node_id: str) -> bool:
    pid = node_pid(node_id)
    if pid:
        os.kill(pid, signal.SIGTERM)
        print(f"  {RED}✗ Killed {node_id} (PID {pid}){RESET}")
        return True
    else:
        print(f"  {AMBER}⚠ {node_id} not found (already down?){RESET}")
        return False


def restart_node(node_id: str, port: int, peers: list[str], base_dir: Path) -> subprocess.Popen:
    node_dir = base_dir / "node"
    env = {
        **os.environ,
        "NODE_ID":        node_id,
        "HOST":           "0.0.0.0",
        "PORT":           str(port),
        "PEERS":          ",".join(peers),
        "DATA_PARTITION": node_id.replace("node_", ""),
    }
    log = open(f"/tmp/fl_{node_id}_restart.log", "w")
    proc = subprocess.Popen(
        [sys.executable, "main.py"], cwd=node_dir, env=env,
        stdout=log, stderr=log
    )
    print(f"  {GREEN}✓ Restarted {node_id} on port {port} (PID {proc.pid}){RESET}")
    return proc


def churn_mode(args, base_dir: Path, base_port: int, n_nodes: int):
    """Continuous random churn: kill a random node periodically."""
    print(f"\n{BOLD}{CYAN}Churn mode active{RESET} — interval={args.interval}s, downtime={args.downtime}s\n")
    all_nodes = [f"node_{i}" for i in range(n_nodes)]
    ports     = {f"node_{i}": base_port + i for i in range(n_nodes)}
    peers_map = {
        f"node_{i}": [f"http://localhost:{base_port + j}" for j in range(n_nodes) if j != i]
        for i in range(n_nodes)
    }

    while True:
        victim = random.choice(all_nodes)
        print(f"\n[{time.strftime('%H:%M:%S')}] {AMBER}Simulating failure of {victim}{RESET}")
        kill_node(victim)
        print(f"  Waiting {args.downtime}s before recovery…")
        time.sleep(args.downtime)
        restart_node(victim, ports[victim], peers_map[victim], base_dir)
        print(f"  {GREEN}{victim} recovered — waiting {args.interval}s{RESET}")
        time.sleep(args.interval)


def main():
    parser = argparse.ArgumentParser(description="Simulate node failures in FL network")
    parser.add_argument("--kill",     type=str, help="Kill a specific node by ID (e.g. node_2)")
    parser.add_argument("--duration", type=int, default=30, help="Downtime in seconds (single kill mode)")
    parser.add_argument("--churn",    action="store_true",  help="Continuous random churn mode")
    parser.add_argument("--interval", type=int, default=30, help="Time between kills (churn mode)")
    parser.add_argument("--downtime", type=int, default=20, help="How long each node stays down")
    parser.add_argument("--base-port",type=int, default=8000)
    parser.add_argument("--nodes",    type=int, default=5)

    args     = parser.parse_args()
    base_dir = Path(__file__).parent.parent

    if args.churn:
        try:
            churn_mode(args, base_dir, args.base_port, args.nodes)
        except KeyboardInterrupt:
            print(f"\n{GREEN}Churn simulation stopped.{RESET}")
        return

    if args.kill:
        print(f"\nKilling {args.kill} for {args.duration}s…")
        killed = kill_node(args.kill)
        if killed:
            time.sleep(args.duration)
            port  = args.base_port + int(args.kill.replace("node_", ""))
            peers = [
                f"http://localhost:{args.base_port + j}"
                for j in range(args.nodes)
                if f"node_{j}" != args.kill
            ]
            restart_node(args.kill, port, peers, base_dir)
        return

    parser.print_help()


if __name__ == "__main__":
    main()
