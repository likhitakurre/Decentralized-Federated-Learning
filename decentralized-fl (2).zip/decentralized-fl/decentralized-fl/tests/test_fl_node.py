"""
Tests for the FL node components.

Run with:
  cd decentralized-fl
  pip install pytest pytest-asyncio
  pytest tests/ -v
"""

import asyncio
import sys
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

# Make node package importable
sys.path.insert(0, str(Path(__file__).parent.parent / "node"))


# ─── Model ────────────────────────────────────────────────────────────────────

class TestFLModel:
    def test_forward_shape(self):
        import torch
        from model import FLModel
        m = FLModel()
        x = torch.randn(4, 1, 28, 28)
        y = m(x)
        assert y.shape == (4, 10)

    def test_weights_roundtrip(self):
        import torch
        from model import FLModel
        m1 = FLModel()
        m2 = FLModel()
        # Give m1 random weights and transfer via dict
        for p in m1.parameters():
            p.data.uniform_(-0.5, 0.5)
        w = m1.get_weights()
        m2.set_weights(w)
        for p1, p2 in zip(m1.parameters(), m2.parameters()):
            assert torch.allclose(p1, p2), "Weights should match after set_weights"

    def test_weight_keys(self):
        from model import FLModel
        m = FLModel()
        keys = list(m.get_weights().keys())
        assert any("fc1" in k for k in keys)
        assert any("fc3" in k for k in keys)

    def test_count_parameters(self):
        from model import FLModel
        m = FLModel()
        n = m.count_parameters()
        assert n > 0
        print(f"\n  Model parameters: {n:,}")


# ─── Aggregation ──────────────────────────────────────────────────────────────

class TestAggregator:
    def _make_weights(self, value: float):
        """Create a trivial weight dict (all values = `value`)."""
        return {"fc1.weight": [[value, value]], "fc1.bias": [value]}

    def test_fedavg_two_peers(self):
        from aggregator import federated_average
        local = self._make_weights(0.0)
        peer  = self._make_weights(1.0)
        result = federated_average(local, [peer])
        assert result["fc1.bias"][0] == pytest.approx(0.5)

    def test_fedavg_no_peers(self):
        from aggregator import federated_average
        local = self._make_weights(0.7)
        result = federated_average(local, [])
        assert result == local

    def test_fedavg_multiple(self):
        from aggregator import federated_average
        local  = self._make_weights(0.0)
        peers  = [self._make_weights(float(i)) for i in range(1, 5)]   # 1, 2, 3, 4
        result = federated_average(local, peers)
        expected = (0 + 1 + 2 + 3 + 4) / 5   # = 2.0
        assert result["fc1.bias"][0] == pytest.approx(expected)

    def test_weighted_fedavg(self):
        from aggregator import weighted_federated_average
        local  = self._make_weights(0.0)
        peer1  = self._make_weights(1.0)
        # local has 100 samples, peer1 has 0 — result should be close to local
        result = weighted_federated_average(local, 100, [peer1], [1])
        assert result["fc1.bias"][0] == pytest.approx(100 / 101, rel=1e-3)

    def test_weighted_fedavg_zero_total(self):
        from aggregator import weighted_federated_average
        local  = self._make_weights(0.5)
        result = weighted_federated_average(local, 0, [], [])
        assert result == local


# ─── Config ───────────────────────────────────────────────────────────────────

class TestNodeConfig:
    def test_defaults(self, monkeypatch):
        monkeypatch.delenv("NODE_ID",    raising=False)
        monkeypatch.delenv("PORT",       raising=False)
        monkeypatch.delenv("PEERS",      raising=False)
        # Re-import to get fresh defaults
        import importlib, config as cfg_mod
        importlib.reload(cfg_mod)
        c = cfg_mod.NodeConfig()
        assert c.node_id == "node_0"
        assert c.port    == 8000
        assert c.peers   == []

    def test_peer_parsing(self, monkeypatch):
        monkeypatch.setenv("PEERS", "http://a:8000, http://b:8001 , ")
        import importlib, config as cfg_mod
        importlib.reload(cfg_mod)
        c = cfg_mod.NodeConfig()
        assert c.peers == ["http://a:8000", "http://b:8001"]


# ─── Gossip engine ────────────────────────────────────────────────────────────

class TestGossipEngine:
    def _make_engine(self):
        import importlib, config as cfg_mod
        importlib.reload(cfg_mod)
        c = cfg_mod.NodeConfig()
        c.peers = ["http://peer1:8000", "http://peer2:8000"]
        c.gossip_fanout   = 2
        c.gossip_interval = 1

        from gossip import GossipEngine
        from model import FLModel
        m = FLModel()
        agg_calls = []
        engine = GossipEngine(
            config=c,
            get_weights_fn=m.get_weights,
            aggregate_fn=lambda ws: agg_calls.append(ws),
        )
        return engine, agg_calls

    def test_add_remove_peer(self):
        engine, _ = self._make_engine()
        engine.add_peer("http://new:9000")
        assert "http://new:9000" in engine.peers
        engine.remove_peer("http://new:9000")
        assert "http://new:9000" not in engine.peers

    def test_get_stats_structure(self):
        engine, _ = self._make_engine()
        stats = engine.get_stats()
        assert "rounds" in stats
        assert "peers"  in stats
        assert "peer_status" in stats

    @pytest.mark.asyncio
    async def test_gossip_round_handles_peer_failure(self):
        """Gossip round should not raise even if all peers are unreachable."""
        engine, agg_calls = self._make_engine()

        async def mock_exchange(session, url):
            return None   # simulate unreachable peer

        with patch.object(engine, "_exchange_with_peer", side_effect=mock_exchange):
            await engine.gossip_round()

        assert engine.stats["rounds"] == 1
        assert agg_calls == []   # no aggregation if no data received

    @pytest.mark.asyncio
    async def test_gossip_round_aggregates_on_success(self):
        """Gossip round should call aggregate callback when peer responds."""
        engine, agg_calls = self._make_engine()
        from model import FLModel
        dummy_weights = FLModel().get_weights()

        async def mock_exchange(session, url):
            return dummy_weights

        with patch.object(engine, "_exchange_with_peer", side_effect=mock_exchange):
            await engine.gossip_round()

        assert len(agg_calls) == 1
        assert len(agg_calls[0]) == 2   # 2 peers responded
