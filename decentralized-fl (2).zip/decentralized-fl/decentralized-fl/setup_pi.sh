#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# setup_pi.sh — One-shot setup for a fresh Raspberry Pi 4
#
# Usage (as pi user):
#   curl -sSL https://raw.githubusercontent.com/yourrepo/decentralized-fl/main/setup_pi.sh | bash
#
# Or clone the repo first, then:
#   chmod +x setup_pi.sh && ./setup_pi.sh
# ─────────────────────────────────────────────────────────────────────────────

set -euo pipefail

CYAN='\033[0;36m'; GREEN='\033[0;32m'; AMBER='\033[0;33m'; RESET='\033[0m'; BOLD='\033[1m'
step()  { echo -e "\n${CYAN}${BOLD}▶ $1${RESET}"; }
ok()    { echo -e "  ${GREEN}✓ $1${RESET}"; }
warn()  { echo -e "  ${AMBER}⚠ $1${RESET}"; }

step "System update"
sudo apt-get update -qq
sudo apt-get install -y --no-install-recommends \
  python3 python3-pip python3-venv git curl
ok "System packages ready"

step "Creating virtual environment"
python3 -m venv ~/.venv/fl
source ~/.venv/fl/bin/activate
ok "venv at ~/.venv/fl"

step "Installing Python dependencies"
pip install --quiet --upgrade pip wheel
pip install --quiet -r requirements.txt
ok "Dependencies installed"

step "Creating systemd service"
NODE_ID="${NODE_ID:-node_0}"
PORT="${PORT:-8000}"
PEERS="${PEERS:-}"
DATA_PARTITION="${DATA_PARTITION:-0}"
REPO_DIR="$(pwd)"

sudo tee /etc/systemd/system/fl-node.service > /dev/null <<EOF
[Unit]
Description=Federated Learning Edge Node (${NODE_ID})
After=network-online.target
Wants=network-online.target

[Service]
User=$(whoami)
WorkingDirectory=${REPO_DIR}
Environment="NODE_ID=${NODE_ID}"
Environment="HOST=0.0.0.0"
Environment="PORT=${PORT}"
Environment="PEERS=${PEERS}"
Environment="DATA_PARTITION=${DATA_PARTITION}"
Environment="DATA_DIR=${REPO_DIR}/data"
Environment="PATH=${HOME}/.venv/fl/bin:/usr/bin:/bin"
ExecStart=${HOME}/.venv/fl/bin/python node/main.py
Restart=on-failure
RestartSec=15
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable fl-node
ok "systemd service installed"

echo ""
echo -e "${BOLD}${GREEN}╔══════════════════════════════════════════╗"
echo -e "║  Setup complete!                         ║"
echo -e "╚══════════════════════════════════════════╝${RESET}"
echo ""
echo -e "  Edit config:  ${CYAN}sudo systemctl edit fl-node${RESET}"
echo -e "  Start node:   ${CYAN}sudo systemctl start fl-node${RESET}"
echo -e "  View logs:    ${CYAN}journalctl -u fl-node -f${RESET}"
echo ""
echo -e "  Make sure to set ${AMBER}PEERS${RESET} before starting:"
echo -e "  ${AMBER}PEERS=http://192.168.1.101:8000,http://192.168.1.102:8000${RESET}"
echo ""
